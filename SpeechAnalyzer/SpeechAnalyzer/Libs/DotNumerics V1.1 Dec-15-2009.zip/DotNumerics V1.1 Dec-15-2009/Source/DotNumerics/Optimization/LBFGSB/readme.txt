﻿L-BFGS-B was translated from FORTRAN to C#. 
The FORTRAN version can be obtained at http://www.eecs.northwestern.edu/~nocedal/lbfgsb.html. 

License of the FORTRAN version:

Condition for Use: This software is freely available, but we expect that all publications describing 
 work using this software , or all commercial products using it, quote at least one of the references given below. 
 
1)R. H. Byrd, P. Lu and J. Nocedal. A Limited Memory Algorithm for Bound Constrained Optimization, (1995), SIAM Journal on Scientific and Statistical Computing , 16, 5, pp. 1190-1208. 
2)C. Zhu, R. H. Byrd and J. Nocedal. L-BFGS-B: Algorithm 778: L-BFGS-B, FORTRAN routines for large scale bound constrained optimization (1997), ACM Transactions on Mathematical Software, Vol 23, Num. 4, pp. 550 - 560. 
