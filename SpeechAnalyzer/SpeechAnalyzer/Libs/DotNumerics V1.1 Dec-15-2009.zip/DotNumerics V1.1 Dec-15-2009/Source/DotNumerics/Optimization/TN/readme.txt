﻿TN was translated from FORTRAN to C#. 

The FORTRAN version can be obtained at http://jblevins.org/mirror/amiller/. 

The Fortran 77 version of this code was written by Stephen Nash's

