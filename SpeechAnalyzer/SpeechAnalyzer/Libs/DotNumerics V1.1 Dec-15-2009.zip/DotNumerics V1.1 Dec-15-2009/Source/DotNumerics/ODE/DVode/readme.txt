﻿DVode was translated from FORTRAN to C#. 
The FORTRAN version can be obtained at https://computation.llnl.gov/casc/odepack/odepack_home.html. 

License of the FORTRAN version:

DVode was written at LLNL. DVode is in the Public Domain and are freely available from 
the CASC Software Download Site (https://computation.llnl.gov/casc/software.html. 
