﻿EISPACK was translated from FORTRAN to C#. 
The FORTRAN version can be obtained at http://www.netlib.org/eispack/. 



