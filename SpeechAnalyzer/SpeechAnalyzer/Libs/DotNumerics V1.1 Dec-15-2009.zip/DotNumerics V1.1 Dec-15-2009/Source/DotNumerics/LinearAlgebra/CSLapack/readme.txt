﻿Lapack was translated from FORTRAN to C#. 
The FORTRAN version can be obtained at http://www.netlib.org/lapack/. 

License of the FORTRAN version:

LAPACK is a freely-available software package. It is available from netlib via anonymous ftp and
 the World Wide Web at http://www.netlib.org/lapack . Thus, it can be included in commercial software packages (and has been).
 We only ask that proper credit be given to the authors.

Like all software, it is copyrighted. It is not trademarked, but we do ask the following:
If you modify the source for these routines we ask that you change the name of the routine 
and comment the changes made to the original. We will gladly answer any questions regarding the software. 
If a modification is done, however, it is the responsibility of the person who modified the routine to provide support.

1.3) How do I reference LAPACK in a scientific publication?

We ask that you cite the LAPACK Users' Guide, Third Edition. 

@BOOK{laug,
      AUTHOR = {Anderson, E. and Bai, Z. and Bischof, C. and
                Blackford, S. and Demmel, J. and Dongarra, J. and
                Du Croz, J. and Greenbaum, A. and Hammarling, S. and
                McKenney, A. and Sorensen, D.},
      TITLE = {{LAPACK} Users' Guide},
      EDITION = {Third},
      PUBLISHER = {Society for Industrial and Applied Mathematics},
      YEAR = {1999},
      ADDRESS = {Philadelphia, PA},
      ISBN = {0-89871-447-8 (paperback)} }


