﻿using System;
using System.Collections.Generic;

using System.Text;

namespace DotNumerics_Samples.Harness
{
    public interface IObjectDumper
    {
        void Write(string s);
    }
}
