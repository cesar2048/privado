﻿using System;
using System.Collections.Generic;

using System.Text;


using System.Configuration;

using DotNumerics_Samples.Harness;

namespace DotNumerics_Samples.Samples
{
    class SchemaInformationBasedSample : SampleSuite
    {

        public SchemaInformationBasedSample()
            : base()
        {
        }

        public override void InitSample(string connectionString)
        {

        }

        public override void TearDownSample()
        {

            base.TearDownSample();
        }
    }
}
